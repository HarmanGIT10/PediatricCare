# PediatricCare – Initial Prototype

A JavaFX desktop prototype for the CSE360 Project Phase 2. It demonstrates role-based login, patient lookup, nurse vitals, doctor prescriptions, pharmacy prescription queue, visit history, and basic admin account management.

## Requirements
- JDK 17 or newer (JDK 21 recommended)
- Apache Maven 3.9+
- Internet connection for the first Maven run (to download JavaFX dependencies)

## Open in VS Code
1. Extract `PediatricCarePrototype.zip`.
2. Open the extracted `PediatricCarePrototype` folder in VS Code.
3. Open Terminal > New Terminal.
4. Run `mvn -version` and `java -version`.

## Run
```powershell
mvn clean javafx:run
```

## Demo accounts
| Role | Username | Password |
|---|---|---|
| Patient | patient | patient123 |
| Nurse | nurse | nurse123 |
| Doctor | doctor | doctor123 |
| Pharmacy | pharmacy | pharm123 |
| Admin | admin | admin123 |

Sample patient: Ava Sharma, date of birth 2014-05-12.

## Notes
- Data is stored in memory and resets when the application closes. This is an initial prototype, not a production medical-record system.
- Blood pressure is requested only for patients older than 12.
- A doctor-created prescription is immediately added to the pharmacy queue.
- Use fictional/demo data only.

## V2 login and hospital booking update
See `docs/V2-LOGIN-APPOINTMENTS.md` for the revised Patient/Hospital login modes, hospital onboarding, hospital-scoped staff administration, patient booking workflow, SQLite data location and remaining prototype limitations.

## Connected care workflow update

The database-backed workflow now includes:

- Appointment requests saved as `PENDING`; hospital administrators can approve or reject them, and the assigned doctor can complete only an approved appointment.
- Patient, hospital-admin, and doctor appointment views read the same SQLite records.
- Doctor examination records and optional prescriptions are saved against the completed appointment.
- Pharmacy staff see hospital-scoped prescriptions and can update fulfilment. Inventory is hospital-scoped; marking a prescription fulfilled consumes one unit of matching stock.
- Patient-to-doctor/nurse messaging is stored in SQLite, scoped to a shared hospital relationship, and displayed in a two-pane chat interface. Patients can select a registered hospital before choosing a care-team contact.
- Notifications and a hospital activity log are persisted.
- Nurses can view approved hospital visits and patient history, and save nursing observations. Nurse permissions do not include prescribing or appointment approval.
- Hospital admins can review appointments, manage staff, see hospital metrics/activity, and update hospital contact information.

The database file is `pediatriccare.db` in the application's working directory. Keep a backup of this file when moving or upgrading the project. The existing legacy sample screens and in-memory sample data are retained for older demonstration accounts; newly registered accounts use the database-backed workflows.

### Important prototype boundaries

This is still a local JavaFX/SQLite prototype, not a deployed multi-user healthcare service. It uses one local database connection and is not designed for simultaneous access from multiple computers. It does not yet provide encrypted transport, a hosted identity service, consent/guardian workflows, audit-grade immutable records, backups, full report uploads, real-time push messaging, a full nurse task assignment system, or a complete medication catalogue. Do not enter real patient or child health information. Before clinical or commercial use, obtain security/privacy review and implement the applicable healthcare and data-protection controls.
