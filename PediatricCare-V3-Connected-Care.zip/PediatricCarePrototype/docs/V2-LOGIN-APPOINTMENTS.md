# PediatricCare – V2 Login, Hospital Tenancy and Appointments

## Login modes
- Patient Login accepts a patient email or username.
- Hospital Login accepts a hospital admin, doctor, nurse or pharmacy account email/username. The stored role selects the dashboard.
- Patient Sign Up creates a patient profile and a hashed-password account.
- Hospital Sign Up creates a hospital tenant and its first hospital-admin account.
- Universal Admin is routed through Patient Login using `admin@gmail.com` / `admin123` as requested.

## Hospital administration
Hospital admin creates doctor, nurse and pharmacy accounts. Staff self-registration is not provided. The SQLite database stores each staff account against the hospital tenant. Staff removal is a soft deactivation. Appointment listing and status updates are constrained by the hospital ID associated with the signed-in hospital admin.

## Patient appointments
Patient chooses a registered hospital, then a doctor listed for that hospital. Doctor name, specialization and treatment focus are displayed. Patient selects a future date, a time slot and reason. The request is saved with `REQUESTED` status. Hospital admin can confirm it. A unique constraint prevents two bookings for the same doctor/date/slot.

## Database
The app creates `pediatriccare.db` in the working directory. SQLite persists hospital registrations, login accounts, doctor directory details, patient profiles and appointment requests. Passwords for newly registered accounts and the universal admin are PBKDF2-HMAC-SHA256 hashes with random salts.

## Important scope and safety notes
This is still a local desktop academic prototype, not a deployable multi-hospital clinical SaaS. Legacy demo clinical records, visits, prescriptions, inventory and messaging remain in the original in-memory application layer; they are not yet fully migrated to tenant-scoped SQLite tables. The new appointment workflow is persistent, but it does not yet feed confirmed bookings into nurse intake/doctor consultation. Hospital information is captured at registration; profile editing, verified email, password reset, audit trails, encryption-at-rest, central server hosting, backups and production privacy/compliance review are not implemented. Do not use real patient data or deploy this build in a real clinic.

## Build/run
Open the folder containing `pom.xml` in IntelliJ. Set Project SDK to JDK 21 (or a compatible newer JDK), reload Maven, then run `clean`, `test`, and `javafx:run`. Maven downloads JavaFX and SQLite JDBC dependencies. Keep the `pediatriccare.db` file to preserve locally registered accounts, hospitals and bookings. Back it up before replacing the project.

## Universal admin credential
`admin@gmail.com` / `admin123` is intentionally created on first database initialization to meet the requested demonstration login. Change/remove this bootstrap credential before any external demonstration or deployment. Never use a shared known password in a production system.
