# PediatricCare — Technical Requirements Document (TRD) / Architecture Blueprint

| Field | Value |
|---|---|
| Document | `TRD.md` – Technical Requirements / Architecture |
| Version | 1.0 |
| Status | Living document – must stay consistent with code and other docs |

---

## 1. Purpose

Define the technical architecture of the PediatricCare prototype: components, layers,
technology stack, data flow, and constraints, so that implementation decisions remain
traceable and reviewers can validate the build against the requirements.

## 2. Architectural Style

**Client-side layered desktop architecture** (no server in prototype):

```
┌────────────────────────────────────────────┐
│ Presentation Layer                         │
│   Launcher, PediatricCareApp (JavaFX UI)  │
├────────────────────────────────────────────┤
│ Business / Service Layer                   │
│   DataStore (auth, patients, visits,     │
│   prescriptions, users)                   │
├────────────────────────────────────────────┤
│ Domain / Model Layer                      │
│   User, Patient, Visit, Prescription     │
├────────────────────────────────────────────┤
│ Data Layer                                │
│   In-memory stores (LinkedHashMap/List)  │
└────────────────────────────────────────────┘
```

## 3. Technology Stack

| Concern | Choice |
|---|---|
| Language | Java 17 (`maven.compiler.release=17`) |
| UI framework | JavaFX 21.0.6 (`javafx-controls`), via javafx-maven-plugin 0.0.8 |
| Build tool | Apache Maven 3.9+ |
| Persistence | In-memory (prototype); DB planned in `Database_Schema.md` |
| Delivery | Desktop (`mvn clean javafx:run`) |

## 4. Component Breakdown

| Component | Responsibility |
|---|---|
| `Launcher` | JavaFX entry point → `Application.launch(PediatricCareApp.class, args)` |
| `PediatricCareApp` | Application lifecycle, login screen, role-based `TabPane` dashboards, view builders, event handlers |
| `DataStore` | Demo users, patient directory, visits, prescriptions, user management; auth + queries |
| `User` | Record: `username`, `password`, `role` |
| `Patient` | Class: first/last name, DOB, username, age, summary |
| `Visit` | Class: patient, staff, timestamp, vitals, diagnosis; **must** support recommendations/allergies/status |
| `Prescription` | Record: patientName, medicine, dosage, prescribedBy, prescribedAt, **+ status** |

## 5. Key Design Decisions & Open Issues (from audit)

1. **Decision:** In-memory prototype store (documented in README). Migration path: `Database_Schema.md`.
2. **Critical issue:** `DataStore.getOrCreateVisit` always creates new visits → nurse/doctor visits must be linked. Fix pending.
3. **Critical issue:** Doctor cannot see nurse-recorded vitals because visits are not shared. Fix pending.
4. **Planned:** Introduce visit status (intake → exam → completed), recommendations, allergies.

## 6. Constraints

- Demo credentials and seed data must not change casually (see `AIGuardrails.md`).
- Keep prototype scope until Phase 3 hardening.
- Public service methods are catalogued in `APIRegistry.md`.

## 7. Traceability

- Requirements → UI screens: `Wireframes.md`
- Requirements → data: `Database_Schema.md`
- Requirements → build order: `Implementation_Plan.md`
