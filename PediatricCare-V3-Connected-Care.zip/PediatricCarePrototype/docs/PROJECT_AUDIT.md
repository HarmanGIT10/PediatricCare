# PediatricCare — Project Audit Report

> Generated: 2026-11-03
> Scope: Code vs. `docs/Phase1_Submission_Template (1).docx` requirements

---

## 1. Context: Documentation vs. Implementation

The Phase 1 submission template defines an **Office Automation System for a Pediatric Doctor's Office** with six roles (Patient/Parent/Guardian, Nurse, Doctor, Administrator, Pharmacy) and a full visit flow.

Audit of what the codebase actually implements:

| Documented Requirement Area | Implementation Status |
|---|---|
| Login (RBAC, error message, admin always available) | ✅ Done |
| Nurse: patient search (first + last + DOB) | ✅ Done |
| Nurse: vitals (temp, pulse, weight, height, BP if >12) | ✅ Done |
| Doctor: consultation + prescription to pharmacy queue | ✅ Done |
| Visit history | ✅ Done (basic) |
| Admin: create account | ✅ Done (basic) |
| Patient: registration / My Information / messaging | ❌ Missing |
| Nurse: patient record (allergies, immunization, contact/insurance/pharmacy), history, messages | ❌ Missing |
| Doctor: ready-for-exam queue, recommendations, review nurse vitals | ❌ Missing |
| Pharmacy: prescription list/details/status | ❌ Missing status workflow |
| Admin: update / deactivate staff accounts | ❌ Missing |
| Functional req: messaging, role management, pharmacy processing, etc. | ⚠️ Partially done |

---

## 2. 🔴 Critical Issues / Bugs

### Bug 1: `DataStore.getOrCreateVisit()` always creates a new Visit
- File: `src/main/java/pediatriccare/DataStore.java` (lines 43–47)
- The method name promises "get or create", but it unconditionally appends a new `Visit`.

**Consequence:** Every nurse vitals save and every doctor consultation creates a separate visit. Patient history fills with duplicates, and data is never linked/updated.

### Bug 2: Nurse intake and doctor consultation use disconnected visits
- Nurse: `PediatricCareApp.java:144-146` → creates visit, sets vitals.
- Doctor: `PediatricCareApp.java:171-173` → creates a *new* visit, sets diagnosis only.

The doctor can never see the nurse's vitals for the current visit, which the docs explicitly require.

### Bug 3: Visit data model is too thin for the documented workflow
- `Visit.java` only stores vitals + diagnosis — no allergies, health concerns, recommendations, status.
- `Prescription.java` stores patient name as a `String`, not a `Patient` reference, and has no status field.

---

## 3. 🟠 High-Priority Gaps

1. No messaging system (explicitly in functional requirements).
2. No patient account creation ("Create an Account" missing from login screen).
3. No pharmacy prescription status workflow (pending/processed…).
4. No admin account update / deactivation.
5. Plaintext password storage (`User.java`, `DataStore.authenticate`).

## 4. 🟡 Medium Issues

- Nurse dashboard lacks history/messages tabs; doctor lacks ready-queue.
- `allVisitSummaries()` exposes all patients' visits to any staff role.
- Generic numeric-validation error message hides field-specific failures.
- Age/BP boundary handled via `Period.getYears()` truncation.
- JavaFX version (21.0.6) vs. compiler release (17) mismatch in `pom.xml`.

## 5. ⚪ Minor / Consistency Issues

- Login demo hint shows only doctor credentials (`PediatricCareApp.java:47`).
- `Visit.nurseUsername` field actually holds staff (nurse *or* doctor) username.
- README references `PediatricCarePrototype.zip` which is not in the repo.
- README labels Phase 2; docs walkthrough is Phase 1.

## 6. ✅ Working Areas

- Login + RBAC switch, demo accounts, patient search by DOB, BP-conditional vitals, prescription auto-queue, in-memory reset behavior.

---

## 7. Recommended Next Steps

1. Fix `getOrCreateVisit` to look up/update existing visit per patient.
2. Extend `Visit`/`Patient` models (allergies, recommendations, status, etc.).
3. Add messaging, pharmacy status, admin update, patient registration.
4. Align UI tabs with docs' role views.
5. Password hashing + tests.

---

*Full narrative version of this audit is in the conversation history; this file is the canonical, persistent copy.*
