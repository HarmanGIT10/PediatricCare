# PediatricCare — Internal API Registry

> Since the prototype is a desktop JavaFX app (no HTTP server), the "API" is the internal
> service-layer contract implemented by `DataStore` and consumed by `PediatricCareApp`.
> This registry must be updated whenever the public surface changes.

| Service | Version | Owner component | Methods |
|---|---|---|---|
| AuthService | 1.0 | `DataStore.authenticate` | `User authenticate(String username, String password)` |
| PatientService | 1.0 | `DataStore.findPatient`, `DataStore.patientForUsername` | `Patient findPatient(String first, String last, LocalDate dob)`, `Patient patientForUsername(String username)` |
| VisitService | 1.0 | `DataStore.getOrCreateVisit`, `visitSummaries`, `allVisitSummaries` | `Visit getOrCreateVisit(Patient patient, String staffUsername)`, `List<String> visitSummaries(Patient patient)`, `List<String> allVisitSummaries()` |
| PrescriptionService | 1.0 | `DataStore.addPrescription`, `prescriptionSummaries` | `void addPrescription(Patient patient, String medicine, String dosage, String doctor)`, `List<String> prescriptionSummaries()` |
| UserService | 1.0 | `DataStore.createUser`, `userSummaries` | `boolean createUser(String username, String password, String role)`, `List<String> userSummaries()` |

## 1. Current DataStore contract (v1.0)

```java
public User authenticate(String username, String password)
public Patient findPatient(String first, String last, LocalDate dob)
public Patient patientForUsername(String username)
public Visit getOrCreateVisit(Patient patient, String staffUsername)
public void addPrescription(Patient patient, String medicine, String dosage, String doctor)
public List<String> prescriptionSummaries()
public List<String> visitSummaries(Patient patient)
public List<String> allVisitSummaries()
public boolean createUser(String username, String password, String role)
public List<String> userSummaries()
```

## 2. Breaking-change rules

- Any signature change in `DataStore` public methods requires: (a) registry version bump,
  (b) UI call-site update in `PediatricCareApp`, (c) test updates.
- Business rules (BP-1..BP-N) are owned by the service layer and must not leak into UI handlers.

## 3. Planned service additions

- `sendMessage`, `replyMessage`, `getThread`.
- `updatePrescriptionStatus(id, status)`.
- `updateUser`, `deactivateUser`.
- `createPatientAccount(...)`.

## 4. Error handling contract

- Auth failure → `null` user → UI shows "Invalid username or password."
- Patient not found → `null` → UI shows not-found message.
- Numeric capture failures → generic validation message in UI (`PediatricCareApp`).
