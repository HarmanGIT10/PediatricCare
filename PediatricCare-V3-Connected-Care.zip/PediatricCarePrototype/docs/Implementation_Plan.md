# PediatricCare — Implementation Plan

| Field | Value |
|---|---|
| Document | `Implementation_Plan.md` |
| Version | 1.0 |
| Status | Living plan – updated after each milestone |

---

## 1. Phase 0 – Foundation (Complete)
- [x] JavaFX 21 + Maven project setup (`pom.xml`, `Launcher`, `PediatricCareApp`).
- [x] In-memory `DataStore` + domain records.
- [x] Login, demo accounts, patient seed (Ava Sharma, 2014-05-12).

## 2. Phase 1 – MVP Prototype (Complete / baseline)
- [x] Role-based dashboards (PATIENT, NURSE, DOCTOR, PHARMACY, ADMIN).
- [x] Patient search (first + last + DOB).
- [x] Nurse vitals + conditional BP (age > 12).
- [x] Doctor diagnosis + prescription → pharmacy queue.
- [x] Basic visit history.
- [x] Admin create account.

## 3. Phase 2 – Core Workflow Fixes (In progress / priority)
- [ ] Fix `DataStore.getOrCreateVisit` to return existing visit when present (critical bug).
- [ ] Unify nurse intake and doctor consult onto the same visit record (critical bug).
- [ ] Extend `Visit`/`Patient` models: allergies, health concerns, recommendations, status.

## 4. Phase 3 – Documented Features (Planned)
- [ ] Doctor: patients-ready-for-exam queue; vitals review; recommendations entry.
- [ ] Nurse: patient history, messages, allergies/health concerns.
- [ ] Pharmacy: prescription details + status workflow (PENDING → PROCESSED/DISPENSED).
- [ ] Admin: update / deactivate staff accounts, role reassignment.
- [ ] Patient: registration, My Information, messaging, prescriptions view.

## 5. Phase 4 – Hardening & Persistence (Future)
- [ ] Move from in-memory to database per `Database_Schema.md`.
- [ ] Password hashing, session handling.
- [ ] Build automation/tests (`mvn clean javafx:run` remains the run command).

## 6. Milestones & Tasks

| Milestone | Key tasks | Depends on |
|---|---|---|
| M1 | Login + dashboards | Phase 1 |
| M2 | Visit lifecycle fix | Phase 2 |
| M3 | Visit model extension | M2 |
| M4 | Pharmacy status + doctor workflow | M3 |
| M5 | Messaging + patient portal | M4 |
| M6 | Persistence + security hardening | M5 |

## 7. Definition of Done (prototype)

- All demo accounts work per `README.md`.
- Nurse → doctor → pharmacy flow keeps a single visit per encounter.
- All screens exist per `Wireframes.md`.
- Requirements traceable in `PRD.md`; technical contract in `APIRegistry.md`.
