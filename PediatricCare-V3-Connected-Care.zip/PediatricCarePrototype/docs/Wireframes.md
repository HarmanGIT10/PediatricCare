# PediatricCare — Wireframes / Frontend Specification

> Companion to `PRD.md` and `TRD.md`. Describes UI screens, layout, and behavior per role.
> Missing pieces are explicitly marked as planned.

## 1. Login Screen

```
+--------------------------------------------------+
|  PediatricCare            (logo/name)           |
|  Healthcare Office Management Prototype        |
|  +----------------+ +------------------------+  |
|  | Username      | | Password             |  |
|  | [__________]  | | [__________]         |  |
|  |                | |                      |  |
|  |                | |             [ Sign in ]|
|  |                | |                (msg)   |
|  +----------------+ +------------------------+  |
|  Demo: doctor / doctor123                        |
+--------------------------------------------------+
```

- Fields: username, password, login button, error label.
- **Gap:** demo hint should list all five accounts (currently doctor-only).

## 2. Patient / Parent / Guardian Dashboard

**Tabs (implemented):** Patient Portal, Visit History

```
[Patient Portal] [Visit History]
---------------------------------
| Patient Portal                          |
|  View your visit records and prescriptions. |
|  [ Visit History list + refresh ]       |
---------------------------------
| Visit History                           |
|  [ list of visit summaries ] [refresh]  |
---------------------------------

**Planned tabs:** My Information, Messages, Prescriptions.
```

## 3. Nurse Dashboard

**Tabs (implemented):** Find Patient, Record Vitals

```
[Find Patient] [Record Vitals]

Find Patient:
  First name [___]  Last name [___]  Birthday [__]
  [ Find patient ]
  → result label

Record Vitals:
  First name, Last name, Birthday
  Temp [___]  Pulse [___]  Weight [___]  Height [___]  BP [___]
  [ Save vitals ]
  → message
```

**Planned:** Patient History tab; Messages tab; allergies & health concerns intake.

## 4. Doctor Dashboard

**Tabs (implemented):** Find Patient, Consultation, Visit History

```
[Find Patient] [Consultation] [Visit History]

Consultation:
  First name, Last name, Birthday
  Diagnosis / notes [________]
  Medicine [________]  Dosage [________]
  [ Save consultation and send prescription to pharmacy ]
  → message
```

**Planned:** "Patients ready for examination" queue; nurse-vitals review; Recommendations section.

## 5. Pharmacy Dashboard

```
[Prescription Queue]

Prescriptions awaiting pharmacy processing:
[ListView of summaries]

[ Refresh queue ]
```

**Planned:** Prescription details view, patient info linkage, status update workflow.

## 6. Admin Dashboard

```
[Account Management]

Protected Admin Account Management
  New username [___]  Temporary password [___]
  Role: [NURSE v] ▼
  [ Create account ]
  → message
  Existing accounts: [ list ]

**Planned:** Update / deactivate staff accounts, role reassignment.
```

## 7. Cross-Cutting UI Notes

- Scene sizing: login `900x620`; dashboard `1050x720`.
- Top bar: heading with role + username, spacer, Log out.
- All tabs non-closable.
- Login default button: Sign in.

## 8. Frontend Gaps Summary

| Screen | Missing (per docs) |
|---|---|
| Login | Create Account button; full demo account list |
| Patient | My Information, Messages, Prescriptions |
| Nurse | Patient History, Messages, allergies/health concerns |
| Doctor | Ready-for-exam queue, Recommendations, vitals review |
| Pharmacy | Status workflow, details |
| Admin | Update/deactivate |
