# PediatricCare — Product Requirements Document (PRD)

| Field | Value |
|---|---|
| Project | PediatricCare – Office Automation System for a Pediatric Doctor's Office |
| Team | PediatricCare / Team 2 (Sagarpreet Singh Cheema, Soumyadip Maity, Ramneek Kaur, Harmanjeet Singh Dhillon) |
| Document version | 1.0 (prototype baseline) |
| Reference docs | `docs/Phase1_Submission_Template (1).docx` |
| Companion docs | `TRD.md`, `Database_Schema.md`, `Wireframes.md`, `Implementation_Plan.md`, `APIRegistry.md`, `AIGuardrails.md` |

---

## 1. Purpose

The PediatricCare system shall enable a pediatric doctor's office to run a complete,
digitized patient visit lifecycle:

**Patient intake (nurse) → Doctor examination & prescription → Pharmacy processing →
Visit history / patient access**, protected by role-based login.

## 2. Scope

### 2.1 In scope (v1 prototype)
- Role-based login for `PATIENT`, `NURSE`, `DOCTOR`, `PHARMACY`, `ADMIN`.
- Patient search by first name + last name + date of birth.
- Nurse vitals capture: temperature, pulse, weight, height; blood pressure required only
  when patient is older than 12 years.
- Doctor consultation: diagnosis + prescription, which is immediately added to the
  pharmacy queue.
- Visit history view.
- Admin account creation.
- In-memory data store (prototype only; resets on app close).

### 2.2 Out of scope (deferred)
- Persistent database storage.
- Full EHR features (immunization history, contact/insurance/pharmacy records, allergies,
  recommendations workflow, messaging, patient self-registration).

## 3. User Personas

| Role | Persona | Core need |
|---|---|---|
| PATIENT | Parent/Guardian | View visit summaries, later messaging & profile info. |
| NURSE | Clinician | Search patient, record intake vitals, prepare patient for exam. |
| DOCTOR | Clinician | Review patient record, record findings, prescribe. |
| PHARMACY | Pharmacist | Receive/queue prescriptions, review, update status. |
| ADMIN | Office admin | Manage staff accounts and access. |

## 4. Functional Requirements

| ID | Requirement | Status |
|---|---|---|
| FR-01 | Login with error message; redirect by role; admin always available. | ✅ Implemented |
| FR-02 | Patient search by first name + last name + DOB. | ✅ Implemented |
| FR-03 | Nurse records vitals; BP required only if age > 12. | ✅ Implemented |
| FR-04 | Doctor records diagnosis + prescription → pharmacy queue. | ✅ Implemented (diagnosis only; recommendations pending) |
| FR-05 | Patient visit history. | ✅ Implemented (basic) |
| FR-06 | Admin creates staff accounts. | ⚠️ Partial (create only) |
| FR-07 | Patient self-registration / My Info / messaging. | ❌ Planned |
| FR-08 | Nurse patient record (allergies, immunization, contact/insurance/pharmacy). | ❌ Planned |
| FR-09 | Doctor ready-for-exam queue + recommendations. | ❌ Planned |
| FR-10 | Pharmacy prescription status updates. | ❌ Planned |
| FR-11 | Visit lifecycle fix (nurse vitals ↔ doctor consult must share a visit). | 🔴 Critical fix pending |

## 5. Non-Functional Requirements

- **Security:** Patient information protected from unauthorized access; demo prototype uses
  in-memory plaintext credentials (production requires hashing + authorization).
- **Reliability:** Data stored accurately without loss within a session; prototype resets on close.
- **Usability:** User-friendly, responsive UI; clear error messages.
- **Performance:** Local desktop app; minimal latency requirements.

## 6. Success Criteria

- All five demo accounts authenticate and land on role-correct dashboards.
- Nurse saves vitals for Ava Sharma (DOB 2014-05-12) → patient record reflects vitals.
- Doctor consultation saves diagnosis and pushes prescription to pharmacy queue.
- Patient portal lists visit summaries for their visits.
