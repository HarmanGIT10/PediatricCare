# PediatricCare — AI Development Guardrails

> Instructions for AI coding assistants (and humans) working in this repository.

## 1. Project context
- Desktop JavaFX prototype; in-memory data store; no backend.
- Purpose: CSE360 Phase 2 prototype for pediatric office automation.

## 2. Hard rules
1. **Never change demo credentials.** `patient/patient123`, `nurse/nurse123`, `doctor/doctor123`,
   `pharmacy/pharm123`, `admin/admin123` and seed patient *Ava Sharma* (DOB 2014-05-12) are fixed.
2. **Never remove or rename public methods** of `DataStore` without updating `APIRegistry.md`.
3. **Never bypass role-based dashboards** – role switch lives in `PediatricCareApp.showDashboard`.
4. **Keep prototype scope** – no production-hardcoded secrets, no real patient data, no persistence
   changes unless the task explicitly targets Phase 3 hardening.

## 3. Code style & patterns
- Use JavaFX `Application` + `Stage`/`Scene` patterns already present.
- Domain records: `User`, `Prescription` (record syntax); classes: `Patient`, `Visit` (encapsulation).
- Keep logic in `DataStore` service methods; UI handlers only call services and render results.

## 4. Verification
- Build/run: `mvn clean javafx:run`
- Compiler target: Java 17.
- If requirements and code drift, update docs (`PRD.md`, `TRD.md`, `Wireframes.md`,
  `Database_Schema.md`) together.

## 5. Safety rails for AI-generated changes
- Do not introduce external services/APIs without updating this file, `TRD.md`, and `PRD.md`.
- Do not add patient-identifiable real-world data.
- Do not weaken the BP-conditional (age > 12) or visit-linking rules without updating docs.
