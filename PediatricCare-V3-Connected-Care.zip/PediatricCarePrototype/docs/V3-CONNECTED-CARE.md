# PediatricCare V3 – Connected Care Workflows

## Persistent workflow

1. Patient selects a hospital, doctor, date and slot. The appointment is stored as `PENDING`.
2. Hospital admin can approve or reject a pending request. The update is tenant-scoped and creates a patient notification.
3. The assigned doctor sees the appointment. Only `APPROVED` appointments can be completed.
4. Completing an appointment saves a medical record and optional prescription, then changes the appointment to `COMPLETED`.
5. The patient sees the same appointment state and medical record. The hospital admin and doctor read the same appointment row.
6. The hospital pharmacy sees prescriptions and manages fulfilment. A `FULFILLED` update requires matching stock and consumes one unit.

## Database additions

- `medical_records`, `prescriptions`, `messages`, `notifications`, `nursing_notes`, `patient_hospitals`, `medication_inventory`, and `activity_log`.
- Appointment status values: `PENDING`, `APPROVED`, `REJECTED`, `COMPLETED`.
- Existing `REQUESTED` and `CONFIRMED` rows are migrated to `PENDING` and `APPROVED` at startup.

## Permissions

- Hospital admins: only their own hospital's appointments, staff, activity and details.
- Doctors: appointments assigned to their account; medical record completion is restricted to their own approved appointments.
- Nurses: approved visits within their hospital, relevant patient history and nursing observations. No prescription or approval actions.
- Pharmacy: prescriptions and stock within their hospital.
- Patients: their own bookings, medical records, notifications and conversations with care-team members at a selected/linked hospital.

## Local run

Open the `PediatricCarePrototype` directory in IntelliJ, reload the Maven project, then run:

```powershell
mvn clean javafx:run
```

The project targets Java 17 and JavaFX 21. The local database is created automatically as `pediatriccare.db` in the process working directory.

## Verification performed in the build environment

- Compiled the non-JavaFX backend/model Java classes with `javac`.
- Executed all SQLite schema statements against an in-memory SQLite database.
- Ran a SQLite workflow smoke test covering booking, approval, examination record/prescription creation, completion, and messaging.
- A full JavaFX/Maven build and interactive UI test could not be run in this environment because Maven and JavaFX dependencies were not installed here. Run the Maven command above in IntelliJ and share the first complete compiler/runtime error if one appears.
