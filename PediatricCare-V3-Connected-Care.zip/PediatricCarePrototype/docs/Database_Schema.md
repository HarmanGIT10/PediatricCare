# PediatricCare — Database Schema (Logical)

> Note: the current prototype stores data in memory (`DataStore`). The schema below is the
> agreed **logical model** that future persistence layers must implement. It is consistent
> with the domain records in `src/main/java/pediatriccare/`.

## 1. ER Overview

```
users ──────────────┐
                     │
patients ───────────┼─────────────── visits ───────────────┐
                     │                                     │
                     │                                     │
                     └──────────── prescriptions ────────┘
```

## 2. Tables

### 2.1 `users`
| Column | Type | Constraints | Notes |
|---|---|---|---|
| username | String | PK, unique (lowercased key) | e.g. `patient`, `nurse` |
| password | String | — | Plaintext in prototype; hashed in production |
| role | String | Enum-like: PATIENT / NURSE / DOCTOR / PHARMACY / ADMIN | RBAC key used by dashboard switch |

### 2.2 `patients`
| Column | Type | Constraints | Notes |
|---|---|---|---|
| firstName | String | — | e.g. `Ava` |
| lastName | String | — | e.g. `Sharma` |
| dateOfBirth | LocalDate | — | e.g. `2014-05-12` |
| username | String | FK → users.username | Owner account login name |

### 2.3 `visits`
| Column | Type | Constraints | Notes |
|---|---|---|---|
| patient | Patient ref | FK → patients | Encountered patient |
| staffUsername | String | FK → users.username | Nurse *or* doctor who created the encounter |
| dateTime | LocalDateTime | — | Auto-set on creation |
| vitals | String | — | Temp/pulse/weight/height/BP; `"Vitals not recorded"` default |
| diagnosis | String | — | Doctor findings; `"Not entered"` default |

> **Critical design gap:** no `recommendations`, `allergies`, `healthConcerns`, or
> `status` columns yet (see `TRD.md` open issues). Planned before Phase 3.

### 2.4 `prescriptions`
| Column | Type | Constraints | Notes |
|---|---|---|---|
| patientName | String | — | Denormalized display name (e.g. `Ava Sharma`) |
| medicine | String | — | Medication name |
| dosage | String | — | Dosage + instructions |
| prescribedBy | String | — | Doctor username |
| prescribedAt | LocalDateTime | — | Auto-set on creation |
| status | String | Planned | e.g. PENDING / PROCESSED / DISPENSED |

## 3. Key Queries (logical)

- `authenticate(username, password) → User?`
- `findPatient(firstName, lastName, dob) → Patient?`
- `patientForUsername(username) → Patient?`
- `getOrCreateVisit(patient, staffUsername) → Visit` — **must become a lookup/update**
- `addPrescription(patient, medicine, dosage, doctor) → void`
- `prescriptionSummaries() → List<String>`
- `visitSummaries(patient?) → List<String>`
- `createUser(username, password, role) → boolean`
- `userSummaries() → List<String>`

## 4. Consistency Rules

1. One visit per patient encounter — nurse vitals and doctor findings must share the visit.
2. Username keys are case-insensitive (lowercased lookup key).
3. Blood pressure is captured only when computed age > 12.
4. Prescription is created only after doctor completes consultation (diagnosis + medicine + dosage).
5. Visit summaries are derived from `visits` joined to `patients`.

## 5. Future Persistence Mapping

When moving from in-memory to a real store (per `Implementation_Plan.md` Phase 3), map:

| In-memory structure | Persistence target |
|---|---|
| `users` map | `users` table |
| `patients` list | `patients` table |
| `visits` list | `visits` table |
| `prescriptions` list | `prescriptions` table |
